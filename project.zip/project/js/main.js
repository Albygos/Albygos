import { blogPosts, getPostById } from './blogData.js';

function createBlogCard(post) {
  return `
    <article class="blog-card">
      <img src="${post.image}" alt="${post.title}" class="blog-image">
      <div class="blog-content">
        <h2 class="blog-title">${post.title}</h2>
        <p class="blog-excerpt">${post.excerpt}</p>
        <div class="blog-meta">
          <span>${post.date}</span> | <span>${post.category}</span>
        </div>
        <a href="post.html?id=${post.id}" class="read-more">Read More</a>
      </div>
    </article>
  `;
}

function initializeBlog() {
  const blogContainer = document.getElementById('blogContainer');
  if (blogContainer) {
    const blogHTML = blogPosts.map(post => createBlogCard(post)).join('');
    blogContainer.innerHTML = blogHTML;
  }

  const postContent = document.getElementById('postContent');
  if (postContent) {
    const urlParams = new URLSearchParams(window.location.search);
    const postId = urlParams.get('id');
    const post = getPostById(postId);
    
    if (post) {
      document.title = `${post.title} - TechInsight Blog`;
      postContent.innerHTML = `
        <article class="blog-post">
          <img src="${post.image}" alt="${post.title}" class="post-image">
          <h1 class="post-title">${post.title}</h1>
          <div class="post-meta">
            <span>${post.date}</span> | <span>${post.category}</span>
          </div>
          <div class="post-content">
            ${post.content.split('\n\n').map(p => `<p>${p}</p>`).join('')}
          </div>
        </article>
      `;
    }
  }
}

document.addEventListener('DOMContentLoaded', initializeBlog);