const blogPosts = [
  {
    title: "The Future of Artificial Intelligence in 2024",
    excerpt: "Exploring the latest developments in AI and what they mean for society...",
    image: "https://picsum.photos/seed/ai1/800/600",
    date: "March 15, 2024",
    category: "AI & ML"
  },
  {
    title: "Web Development Trends That Will Dominate 2024",
    excerpt: "From WebAssembly to Edge Computing, these trends are reshaping web development...",
    image: "https://picsum.photos/seed/web1/800/600",
    date: "March 14, 2024",
    category: "Web Dev"
  },
  {
    title: "Understanding Quantum Computing Basics",
    excerpt: "A beginner's guide to quantum computing and its potential applications...",
    image: "https://picsum.photos/seed/quantum1/800/600",
    date: "March 13, 2024",
    category: "Technology"
  },
  {
    title: "5G Technology: Impact on Mobile Development",
    excerpt: "How 5G is revolutionizing mobile app development and user experiences...",
    image: "https://picsum.photos/seed/5g1/800/600",
    date: "March 12, 2024",
    category: "Mobile"
  },
  {
    title: "Cybersecurity Best Practices for 2024",
    excerpt: "Essential security measures every organization should implement...",
    image: "https://picsum.photos/seed/security1/800/600",
    date: "March 11, 2024",
    category: "Security"
  },
  {
    title: "Machine Learning in Healthcare",
    excerpt: "Revolutionary applications of ML in modern medical diagnosis...",
    image: "https://picsum.photos/seed/health1/800/600",
    date: "March 10, 2024",
    category: "AI & ML"
  },
  {
    title: "The Rise of Low-Code Development Platforms",
    excerpt: "How low-code platforms are changing the software development landscape...",
    image: "https://picsum.photos/seed/lowcode1/800/600",
    date: "March 9, 2024",
    category: "Web Dev"
  },
  {
    title: "Cloud Computing: Latest Innovations",
    excerpt: "New developments in cloud technology and their business impact...",
    image: "https://picsum.photos/seed/cloud1/800/600",
    date: "March 8, 2024",
    category: "Technology"
  },
  {
    title: "The Evolution of Mobile UI Design",
    excerpt: "Tracking the changes in mobile interface design over the years...",
    image: "https://picsum.photos/seed/ui1/800/600",
    date: "March 7, 2024",
    category: "Mobile"
  },
  {
    title: "Blockchain Beyond Cryptocurrency",
    excerpt: "Innovative applications of blockchain in various industries...",
    image: "https://picsum.photos/seed/blockchain1/800/600",
    date: "March 6, 2024",
    category: "Technology"
  },
  {
    title: "The Impact of GPT-4 on Software Development",
    excerpt: "How advanced language models are changing coding practices...",
    image: "https://picsum.photos/seed/gpt1/800/600",
    date: "March 5, 2024",
    category: "AI & ML"
  },
  {
    title: "Progressive Web Apps in 2024",
    excerpt: "The latest features and benefits of Progressive Web Applications...",
    image: "https://picsum.photos/seed/pwa1/800/600",
    date: "March 4, 2024",
    category: "Web Dev"
  },
  {
    title: "IoT Security Challenges and Solutions",
    excerpt: "Addressing the security concerns in Internet of Things devices...",
    image: "https://picsum.photos/seed/iot1/800/600",
    date: "March 3, 2024",
    category: "Security"
  },
  {
    title: "Cross-Platform Mobile Development Tools",
    excerpt: "Comparing the best tools for multi-platform mobile development...",
    image: "https://picsum.photos/seed/mobile1/800/600",
    date: "March 2, 2024",
    category: "Mobile"
  },
  {
    title: "Data Privacy in the Age of AI",
    excerpt: "Balancing innovation with personal data protection...",
    image: "https://picsum.photos/seed/privacy1/800/600",
    date: "March 1, 2024",
    category: "Security"
  },
  {
    title: "The Future of Edge Computing",
    excerpt: "How edge computing is reshaping data processing and delivery...",
    image: "https://picsum.photos/seed/edge1/800/600",
    date: "February 29, 2024",
    category: "Technology"
  },
  {
    title: "DevOps Best Practices for 2024",
    excerpt: "Modern approaches to development operations and automation...",
    image: "https://picsum.photos/seed/devops1/800/600",
    date: "February 28, 2024",
    category: "Web Dev"
  },
  {
    title: "Augmented Reality in Mobile Apps",
    excerpt: "Creating immersive mobile experiences with AR technology...",
    image: "https://picsum.photos/seed/ar1/800/600",
    date: "February 27, 2024",
    category: "Mobile"
  },
  {
    title: "Natural Language Processing Advances",
    excerpt: "Recent breakthroughs in NLP and their practical applications...",
    image: "https://picsum.photos/seed/nlp1/800/600",
    date: "February 26, 2024",
    category: "AI & ML"
  },
  {
    title: "Sustainable Technology Practices",
    excerpt: "How tech companies are adopting eco-friendly approaches...",
    image: "https://picsum.photos/seed/green1/800/600",
    date: "February 25, 2024",
    category: "Technology"
  }
];

function createBlogCard(post) {
  return `
    <article class="blog-card">
      <img src="${post.image}" alt="${post.title}" class="blog-image">
      <div class="blog-content">
        <h2 class="blog-title">${post.title}</h2>
        <p class="blog-excerpt">${post.excerpt}</p>
        <div class="blog-meta">
          <span>${post.date}</span> | <span>${post.category}</span>
        </div>
        <a href="#" class="read-more">Read More</a>
      </div>
    </article>
  `;
}

function initializeBlog() {
  const blogContainer = document.getElementById('blogContainer');
  const blogHTML = blogPosts.map(post => createBlogCard(post)).join('');
  blogContainer.innerHTML = blogHTML;
}

document.addEventListener('DOMContentLoaded', initializeBlog);